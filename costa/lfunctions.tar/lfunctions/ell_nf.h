#include "string.h"
#include "acb_poly.h"
#include "pari.h"
#include "structs.h"
#include <iostream>

#ifndef STRUCTS_H
#define STRUCTS_H

using namespace std;
bool do_lpolys_ell_nf(L_func_t *L, L_family_t *Lf, L_comp_t *Lc, int64_t prec)
{
    long* an = (long*)malloc(L->M * sizeof(long));
    char s1[BUFF_LEN], s2[BUFF_LEN], s3[BUFF_LEN];
    if( sscanf(L->setup_string, "%llu %s \"%s\" \"%s\"", &L->N, s1, s2, s3 ) != 4)
        return false;

    //L->N = conductor
    //s1 = EC coeff
    //s2 = numberfield polynomial
    //use pari to compute Dirichlet coefficients 
    if( not lfunan_ecnf(an, L->M, s1, s2) )
        return false;
    // copy the coefficients
    for(uint64_t m=0; m < L->M; m++)
        acb_set_si(L->ans[m], an[m]);
    //FIXME
    // and compute the 2nd moment
    free(an);
    return true;
}

bool elliptic_nf_parse_line(L_func_t *L)
{
    cout << "Processing line: " << L->setup_string << endl;
    char label[BUFF_LEN], filename[BUFF_LEN];
    char s1[BUFF_LEN], s2[BUFF_LEN];
    if( sscanf(L->setup_string, "%llu %s \"%s\" \"%s\"", &L->N, label, s1, s2 ) != 4)
            return false;
    printf("label: %s\nfilename: %s\n elliptic curve coefficients: %s\n where %s == 0\n", label, filename, s1, s2);
    return true;
}
#endif



