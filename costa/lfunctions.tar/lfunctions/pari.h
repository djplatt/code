#ifndef PARI_H
#define PARI_H

#undef ulong
#include <pari/pari.h>
#include <setjmp.h>
#include "defines.h"

static void sigint_handler(void) { exit(0); }
static jmp_buf env;
static const char *inputstring;
static void error_handler(long numerr) {
  fprintf(stderr,"pari error while processing %s\n",inputstring);
  longjmp(env,numerr);
}

static char *pari(const char *s) {
  static int pari_initialized;
  char *res;
  pari_sp av;

  if (!pari_initialized) {
    printf("initializing pari");
    pari_init(500000000,0);
    cb_pari_err_recover = error_handler;
    cb_pari_sigint = sigint_handler;
    pari_initialized = 1;
  }

  av = avma;
  inputstring = s;
  if (setjmp(env))
    res = (char *)0;
  else
    res = GENtostr(gp_read_str(s));
  avma = av;
  return res;
}

static long parilong(const char *s) {
  char *buf = pari(s);
  long res;
  if (!buf) return 0;
  if (sscanf(buf,"%ld",&res) != 1) res = 0;
  free(buf);
  return res;
}

static char *paristr(char *s) {
  char *buf = pari(s);
  if (!buf) return (char *)0;
  strcpy(s,buf);
  free(buf);
  return s;
}


void naive_atol(long &x, const char *p) {
  x = 0;
  bool neg = false;
  if (*p == '-') {
    neg = true;
    ++p;
  }
  while (*p >= '0' && *p <= '9') {
    x = (x*10) + (*p - '0');
    ++p;
  }
  if (neg) {
    x = -x;
  }
}

bool parilongvec(long vec[], long len, const char *s) {
  char *buf = pari(s);
  if (!buf)
    return false;

  char *chunk;
  chunk = strtok(buf, "[");
  long i = 0;
  chunk = strtok(chunk, ",]");
  while( chunk != NULL and i < len)
  {
    //        naive_atol(vec[i], chunk);
    vec[i] = atol(chunk);
    //        if (sscanf(chunk,"%ld", vec + i) != 1)
    //            return false;
    chunk = strtok(NULL, ",]");
    ++i;
  }
  free(buf);
  return true;
}

bool lfunan(long vec[], long len, const char *pari_object )
{
  char command[BUFF_LEN];
  sprintf(command,"lfunan( %s, %ld)", pari_object, len);
  return parilongvec(vec, len, command);
}

bool lfunan_ecnf(long vec[], long len, const char *EC_coeff, const char *field_poly )
{
  char command[BUFF_LEN];
  sprintf(command,"lfunan( ellinit(%s, nfinit(%s) ), %ld)", EC_coeff, field_poly, len);
  return parilongvec(vec, len, command);
}

#endif



