#include "pari.c"
#define M 1000000

int main()
{
    long an[M];
    for(size_t i = 0; i < 10; i++)
        lfunan_ecnf(an, M, "[0, 0, 0, -3219885*a - 21441132, 3538467720*a + 23562337806]", "a^2 - a - 51");
    return 0;    
}
