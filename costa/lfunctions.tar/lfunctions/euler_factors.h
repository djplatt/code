#ifndef EULER_FACTORS_H
#define EULER_FACTORS_H

#include <string.h>
#include <acb_poly.h>
#include <iostream>
#include <fstream>
#include <cstdint>
#include "structs.h"
#include "coeffs.h"
#include "acb.h"
#include "defines.h"


using namespace std;
//**********************************************************************
// utility routines by Andy Booker
//**********************************************************************


/* invert the polynomial p to precision k */
static void inverse(int64_t *ans, int64_t *p, int64_t k) {
  int64_t i,j,c[32];

  c[0] = 1;
  for (j=1;j<=k;j++) c[j] = 0;
  for (i=0;i<=k;i++) {
    ans[i] = c[0];
    for (j=1;j<=k-i;j++)
      c[j-1] = c[j]-p[j]*ans[i];
  }
}

// floor(log(x)/log(p))
static inline int logp(uint64_t x, uint64_t p) {
  int k;
  for (k=0;x>=p;k++)
    x /= p;
  return k;
}

static int acb_set_str(acb_t res, const char * input, slong prec)
{
  //input = " real_part, imag_part ";
  char* buf;
  buf = new char[strlen(input) + 1];
  strcpy(buf, input);
  int result = 0;
  //discard
  int comma = strcspn(buf, ",");
  buf[comma] = '\0';
  result += arb_set_str( acb_realref(res), buf , prec);
  result += arb_set_str( acb_imagref(res), buf + comma + 1, prec);
  delete[] buf;
  return result;
}



// polynomial coefficients are long ints
// L->setup_string is the filename to read from
void read_euler_factors_ZZ(L_func_t *L, const int64_t &prec)
{
  int64_t f[64], c[64];
  int64_t p, pi, i, j, k;
#ifdef HASH
  int64_t an_hash[hashmax];
  if( L->M < hashmax )
    L->M = hashmax;
#endif

  pi = 2;
  i = 1;
  //precompute enough primes
  n_prime_pi(L->M+1);

  ifstream file(L->filename, ifstream::in);
  printf("Importing euler factors from: %s\n", L->filename);
  char buffer[BUFF_LEN];
  char* chunk;

  p = 0;
  printf("L->M = %llu\n", L->M);

  while( file.good()  and not file.eof() )
  {
    file.getline(buffer, BUFF_LEN);

    //read the prime
    chunk = strtok(buffer, ",");
    if( chunk == NULL )
      //no more lines to read
      break;
    p = strtoll(chunk, NULL, 10);
    pi = n_nth_prime(i);
    while( p > pi )
    {
      //printf("no euler factor for p = %d\n", pi);
      //no euler factor for pi
      c[0] = 1;
      for(j= 1; j < 64; j++)
        c[j] = 0;
      if(pi <= L-> M)
        use_inv_lpoly(L, pi, c, prec);

      i++;
      pi = n_nth_prime(i);
    }
    i++;
    //printf("p = %d\n", p);

    if( p > L->M  )
      break;
    //read the coefficients of the euler factor
    j = 0;
    chunk = strtok(NULL, "[");
    chunk = strtok(NULL, ",]");
    while( chunk != NULL )
    {
      //printf("%s\n", chunk);
      f[j] = strtoll(chunk, NULL, 10);
      chunk = strtok(NULL, ",]");
      j++;
      if( j >= 64)
      {
        cout<<p<<endl;
        abort();
      }
    }
    for (;j<64;j++) f[j] = 0;
    k = logp(L->M, p);
    // invert the polynomial to required precision
    inverse(c, f, k);
    // compute Dirichlet coefficients with it
      use_inv_lpoly(L, p, c, prec);
  }

  if( p <= L->M )
  {
    //we can't fill out any more coefficients
    L->M = p+1;
    printf("Truncating Dirichlet coefficients\n");
  }



  printf("p = %lld\n", p);
  printf("L->M = %d\n", L->M);
  printf("Done importing: %s\n", L->filename);
  file.close();
  if (p == 0){
    printf("No line was read! Missing file?\n");
    abort();
  }
}

// polynomial coefficients are list of CC
// L->setup_string is of the format = "bits_of_precicison filename"
void read_euler_factors_CC(L_func_t *L, const int64_t &prec)
{
  printf("euler\n\n");
  acb_t tmp;
  acb_init(tmp);
  acb_poly_t f, c;
  acb_poly_init(c);
  acb_poly_init(f);
  acb_poly_fit_length(c, 64);
  acb_poly_fit_length(f, 64);
  int64_t p, pi, i, j, k;


  pi = 2;
  i = 1;
  //precompute enough primes
  n_prime_pi(L->M);

  ifstream file(L->filename, ifstream::in);
  printf("Importing euler factors from: %s\n", L->filename);
  char buffer[BUFF_LEN];
  char* chunk;


  p = 0;
  printf("L->M = %llu\n", L->M);
  while( file.good()  and not file.eof() )
  {
    file.getline(buffer, BUFF_LEN);



    //read the prime
    chunk = strtok(buffer, ",");
    if( chunk == NULL )
      //no more lines to read
      break;
    p = strtoll(chunk, NULL, 10);
    pi = n_nth_prime(i);
    while( p > pi )
    {
      //printf("no euler factor for p = %d\n", pi);
      //no euler factor for pi
      acb_poly_one(c);
      use_inv_lpoly(L, pi, c, prec);
      i++;
      pi = n_nth_prime(i);
    }
    i++;

    if( (uint64_t) p > L->M)
      break;
    //read the coefficients of the euler factor
    j = 0;
    chunk = strtok(NULL, "]");
    chunk += strcspn(chunk, "-.0123456789");
    acb_poly_one(f);
    while( chunk != NULL )
    {
      //printf("%s\n", chunk);
      acb_set_str( tmp , chunk , prec);
      //printf("j = %lld ", j);
      //acb_printn(tmp, 2,0);
      //printf("\n");
      acb_poly_set_coeff_acb(f, j, tmp);
      chunk = strtok(NULL , "[");
      chunk = strtok(NULL, "]");
      j++;
    }
    for (;j<64;j++)
      acb_poly_set_coeff_si(f, j, 0);
    k = logp(L->M, p);
    // invert the polynomial to required precision
    acb_poly_inv_series(c, f, 64, prec);
    // compute Dirichlet coefficients with it
    use_inv_lpoly(L, p, c, prec);
  }
  if( (uint64_t)p <= L->M )
  {
    //we can't fill out any more coefficients
    L->M = p+1;
    printf("Truncating Dirichlet coefficients\n");
  }

  acb_poly_clear(c);
  acb_poly_clear(f);
  acb_clear(tmp);
  printf("p = %lld\n", p);
  printf("L->M = %llu\n", L->M);
  printf("Done importing: %s\n", L->filename);
  file.close();
  //no line was read
  if (p == 0){
    printf("No line was read! Missing file?\n");
    abort();
  }
}

bool do_lpoly_euler_factors(L_func_t *L, L_family_t *Lf, L_comp_t *Lc, int64_t prec)
{
  // initialise all the Dirichlet coefficients to 1
  for(int64_t m=0; m < (int64_t) L->M; m++)
    acb_set_ui(L->ans[m], 1);
  switch(Lf->ltype)
  {
    case EULER_FACTORS_ZZ:
      read_euler_factors_ZZ(L, prec);
      return true;
    case EULER_FACTORS_CC:
      read_euler_factors_CC(L, prec);
      return true;
    default:
      return false;
  }

}

bool parse_line_euler_factors(L_func_t *L)
{
  cout << "Processing line: " << L->setup_string;
  if( sscanf(L->setup_string, "%lld %d %lld %s %s", &L->wt, &L->self_dual_p, &L->N, &L->label, &L->filename) != 5)
    cout << "Failed to process line: " << L->setup_string;
  printf("label: %s\nfilename: %s\nconductor: %ld\nweight: %ld\n", L->label, L->filename, L->N, L->wt);
  return true;
}


#endif 
