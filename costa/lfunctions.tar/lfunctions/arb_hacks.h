ARB_INLINE void
arb_get_lbound_arf(arf_t u, const arb_t x, long prec)
{
    arf_t t;
    arf_init_set_mag_shallow(t, arb_radref(x));

    arf_sub(u, arb_midref(x), t, prec, ARF_RND_FLOOR);
}


